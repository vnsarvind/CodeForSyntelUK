﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.ServiceModel.Web;
using System.Text;
using MerchantEnrollment.Models;
using MerchantRepository;

namespace MerchantService
{
    // NOTE: You can use the "Rename" command on the "Refactor" menu to change the class name "Service1" in code, svc and config file together.
    public class MerchantService : IMerchantService
    {
        private static List<MerchantModels> _merchantInformation;
        public MerchantService()
        {
            _merchantInformation = MerchantRepository.MerchantRepository.merchantData;
        }

        public List<MerchantModels> GetAllMerchantDetails()
        {
            var result = _merchantInformation;
            return result;
        }

        public MerchantModels GetMerchantDetails(string merchantName)
        {
            var result = _merchantInformation.Find(x => x.MerchantName == merchantName);
            return result;
        }

        public List<MerchantModels> SearchMerchantByName(string merchantName)
        {
            List<MerchantModels> searchedData = new List<MerchantModels>();
            searchedData = _merchantInformation.Where(x => x.MerchantName == merchantName).ToList();
            return searchedData;
        }

        public List<MerchantModels> SearchMerchantByCountry(string countryName)
        {
            List<MerchantModels> searchedData = new List<MerchantModels>();
            searchedData = _merchantInformation.Where(x => x.Country == countryName).ToList();
            return searchedData;
        }

        public void AddMerchantDetails(MerchantModels addMerchantData)
        {
            _merchantInformation.Add(addMerchantData);           
        }

        public void EditMerchantData(MerchantModels editMerchantData)
        {
            var itemToRemove = _merchantInformation.Single(r => r.MerchantName == editMerchantData.MerchantName);
            _merchantInformation.Remove(itemToRemove);
            _merchantInformation.Add(editMerchantData);
        }

        public void RemoveMerchantDetails(MerchantModels removeMerchantData)
        {
            var itemToRemove = _merchantInformation.Single(r => r.MerchantName == removeMerchantData.MerchantName);
            _merchantInformation.Remove(itemToRemove);
        }
    }
}
