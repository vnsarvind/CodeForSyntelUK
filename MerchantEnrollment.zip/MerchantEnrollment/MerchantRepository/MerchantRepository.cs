﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using MerchantEnrollment.Models;
using System.Globalization;

namespace MerchantRepository
{
    public class MerchantRepository
    {
        public static List<MerchantModels> merchantData;

        static MerchantRepository()
        {
            if (merchantData == null)
                merchantData = new List<MerchantModels>();

            merchantData.Add(new MerchantModels()
            {
                MerchantName = "Bank-E",
                AddedBy = "Joe Bloggs",
                Country = "England",
                MerchantProfit = 10000,
                DateAdded = Convert.ToDateTime("01/01/2016"),
                NumberOfOutlets = 15
            });

            merchantData.Add(new MerchantModels()
            {
                MerchantName = "Member-A",
                AddedBy = "Ray Brando",
                Country = "Italy",
                MerchantProfit = 243789,
                DateAdded = Convert.ToDateTime("11/01/2016"),
                NumberOfOutlets = 1300
            });

            merchantData.Add(new MerchantModels()
            {
                MerchantName = "Member-F",
                AddedBy = "Roy Hills",
                Country = "Germany",
                MerchantProfit = 24000,
                DateAdded = Convert.ToDateTime("12/02/2016"),
                NumberOfOutlets = 500
            });

            merchantData.Add(new MerchantModels()
            {
                MerchantName = "Bank-A",
                AddedBy = "George Mason",
                Country = "USA",
                MerchantProfit = 500000,
                DateAdded = Convert.ToDateTime("12/02/2016"),
                NumberOfOutlets = 20000
            });

            merchantData.Add(new MerchantModels()
            {
                MerchantName = "Bank-B",
                AddedBy = "Alex Tory",
                Country = "India",
                MerchantProfit = 20000,
                DateAdded = Convert.ToDateTime("04/15/2016"),
                NumberOfOutlets = 230
            });

            merchantData.Add(new MerchantModels()
            {
                MerchantName = "Bank-C",
                AddedBy = "Malcolm Davies",
                Country = "Portugal",
                MerchantProfit = 13000,
                DateAdded = Convert.ToDateTime("04/15/2016"),
                NumberOfOutlets = 400
            });
        }

    }
}
