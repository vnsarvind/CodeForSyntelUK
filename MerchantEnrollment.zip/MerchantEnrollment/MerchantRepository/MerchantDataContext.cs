﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data.Entity;

namespace MerchantRepository
{
    public class MerchantDataContext:DbContext
    {
        // To be used during saving of data in database
        public DbSet<MerchantRepository> MerchantDatas { get; set; }
    }
}
