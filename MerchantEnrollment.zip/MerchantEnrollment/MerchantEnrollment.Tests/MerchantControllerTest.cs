﻿using MerchantEnrollment.Controllers;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System.Web.Mvc;
using MerchantEnrollment.MerchantService;
using MerchantEnrollment.Controllers;
using System;
using Microsoft.VisualStudio.TestTools.UnitTesting.Web;
using System.Collections.Generic;

namespace MerchantEnrollment.Tests
{
    [TestClass()]
    public class MerchantControllerTest
    {


        [TestMethod()]
        public void IndexTest()
        {
            MerchantController target = new MerchantController();
            ViewResult result = target.Index() as ViewResult;
            Assert.IsNotNull(result);
        }

        [TestMethod()]
        public void CreateTest()
        {
            MerchantController target = new MerchantController();
            ViewResult result = target.Create() as ViewResult;
            Assert.IsNotNull(result);
        }

        [TestMethod()]
        public void DeleteTest()
        {
            MerchantController target = new MerchantController();
            ViewResult result = target.Delete("Bank-E") as ViewResult;
            Assert.IsNotNull(result);
        }
                        
        [TestMethod()]
        public void DetailsTest()
        {
            MerchantController target = new MerchantController();
            ViewResult result = target.Details("Bank-E") as ViewResult;
            Assert.IsNotNull(result);
        }

    }
}
