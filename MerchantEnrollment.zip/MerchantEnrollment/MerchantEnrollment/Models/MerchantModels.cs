﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel;

namespace MerchantEnrollment.Models
{
    public partial class MerchantModels
    {
        [DisplayName("Merchant Name")]
        public string MerchantName { get; set; }
        [DisplayName("Added By")]
        public string AddedBy { get; set; }
        [DisplayName("Country Name")]
        public string Country { get; set; }
        [DisplayName("Merchant Profit(In Euro)")]
        [DisplayFormat(ApplyFormatInEditMode = true, DataFormatString = "{0:N}")]
        public double MerchantProfit { get; set; }
        [DisplayName("Date Added")]
        [DisplayFormat(ApplyFormatInEditMode = true, DataFormatString = "{0:MM/dd/yyyy}")]
        public DateTime DateAdded { get; set; }
        [DisplayName("Number Of Outlets")]
        public int NumberOfOutlets { get; set; }                 
    }

    // puttting in separate project /  file is a better option

   
    public partial class MerchantModels : IValidatableObject
    {
        public IEnumerable<ValidationResult> Validate(ValidationContext validationContext)
        {
            var results = new List<ValidationResult>();

            if (NumberOfOutlets < 10)
            {
                results.Add(new ValidationResult("Minimum Number of Outlets allowed for any Merchant to be added is 10", new[] { "NumberOfOutlets" }));
            }

            if ((Country == "France") || (Country == "Spain"))
            {
                var input = new DateTime(9999, DateAdded.Month, DateAdded.Day);
                var startDateFrance = new DateTime(9999, 01, 10);
                var endDateFrance = new DateTime(9999, 02, 24);

                if (input > startDateFrance && input < endDateFrance  && Country == "France")
                {
                    results.Add(new ValidationResult("Merchants being added during Jan 10th to Feb 24th cannot be added in France", new[] { "Country", "DateAdded" }));
                }

                var startDateSpain = new DateTime(9999, 02, 15);
                var endDateSpain = new DateTime(9999, 04, 01);

                if (input > startDateSpain && input < endDateSpain && Country == "Spain")
                {
                    results.Add(new ValidationResult("Merchants being added during Feb 15th to April 1st cannot be added in Spain", new[] { "Country", "DateAdded" }));
                }
            }

            if (MerchantProfit < 1)
            {
                results.Add(new ValidationResult("MerchantProfit cannot be null", new[] { "MerchantProfit" }));
            }

            if(string.IsNullOrWhiteSpace(MerchantName))
            {
               results.Add(new ValidationResult("MerchantName cannot be null", new[] { "MerchantName" }));
            }

          return results;
        }
    }
    
}
