﻿using System.Collections.Generic;
using System.Web.Mvc;
using MerchantEnrollment.MerchantService;

namespace MerchantEnrollment.Controllers
{
    [HandleError]
    public class MerchantController : Controller
    {
        private MerchantServiceClient merchantServiceClient;

        public MerchantController()
        {
            if (merchantServiceClient == null)
                merchantServiceClient = new MerchantServiceClient();
        }

        public ActionResult Index()
        {
            ViewBag.MerchantInormation = "";

            var merchantModelData = new List<MerchantEnrollment.Models.MerchantModels>();

            if (!TempData.ContainsKey("SearchByValue"))
            {
                var merchantServiceData = merchantServiceClient.GetAllMerchantDetails();
                merchantModelData = GetListModelData(merchantServiceData);
            }

            var SearchResults = TempData.ContainsKey("SearchByValue") ? TempData["SearchByValue"] as IEnumerable<object> : merchantModelData;

            return View(SearchResults);
        }        

        public ActionResult Details(string merchantName)
        {
            var merchantServiceData = merchantServiceClient.GetMerchantDetails(merchantName.Trim());
            var merchantModelData = GetModelData(merchantServiceData);
            return View(merchantModelData);
        }

        public ActionResult Search(FormCollection collection)
        {

            string condition = collection["condition"];
            string keyword = collection["keyword"];

            if (condition.Equals("searchByMerchantName"))
            {
                var merchantServiceListData = merchantServiceClient.SearchMerchantByName(keyword.Trim());
                var merchantModelListData = GetListModelData(merchantServiceListData);
                TempData["SearchByValue"] = merchantModelListData;
            }
            else if (condition.Equals("searchByCountryName"))
            {
                var merchantServiceListData = merchantServiceClient.SearchMerchantByCountry(keyword.Trim());
                var merchantModelListData = GetListModelData(merchantServiceListData);
                TempData["SearchByValue"] = merchantModelListData;
            }

            return RedirectToAction("Index");
        }

        public ActionResult Create()
        {
            return View();
        }

        public ActionResult Edit(string merchantName)
        {
            var merchantServiceDetails = merchantServiceClient.GetMerchantDetails(merchantName.Trim());
            var merchantModelDetails = GetModelData(merchantServiceDetails);
            return View(merchantModelDetails);
        }

        public ActionResult Delete(string merchantName)
        {
            var merchantServiceData = merchantServiceClient.GetMerchantDetails(merchantName.Trim());

            var merchantModelData = GetModelData(merchantServiceData);

            return View(merchantModelData);
        }

        [HttpPost]
        public ActionResult Create(MerchantEnrollment.Models.MerchantModels merchantModel)
        {
            try
            {
                var checkMerchantInfo = merchantServiceClient.GetMerchantDetails(merchantModel.MerchantName.Trim());
                if (checkMerchantInfo != null)
                {
                    ViewBag.MerchantInormation = "No duplicate merchant name can be added";
                    ViewBag.Visible = true;
                }
                else
                {
                    ViewBag.MerchantInormation = string.Empty;

                }
                if ((ModelState.IsValid) && (checkMerchantInfo == null))
                {
                    var merchantServiceData = GetServiceData(merchantModel);
                    merchantServiceClient.AddMerchantDetails(merchantServiceData);
                    return RedirectToAction("Index");
                }
                else
                    return View(merchantModel);

            }
            catch
            {
                return View();
            }
        }       
        
        [HttpPost]
        public ActionResult Edit(MerchantEnrollment.Models.MerchantModels merchantModel)
        {
            try
            {
                if ((ModelState.IsValid))
                {

                    var serviceData = GetServiceData(merchantModel);
                    merchantServiceClient.EditMerchantData(serviceData);
                    return RedirectToAction("Index");
                }
                else
                    return View(merchantModel);
            }
            catch
            {
                return View();
            }
        }       
        
        [HttpPost]
        public ActionResult Delete(Models.MerchantModels merchantModelData)
        {
            try
            {
                var merchantServiceData = GetServiceData(merchantModelData);
                merchantServiceClient.RemoveMerchantDetails(merchantServiceData);

                return RedirectToAction("Index");
            }
            catch
            {
                return View();
            }
        }

        [NonAction]
        public static Models.MerchantModels GetModelData(MerchantService.MerchantModels serviceData)
        {
            var modelData = new Models.MerchantModels();

            modelData.MerchantName = serviceData.MerchantName;
            modelData.AddedBy = serviceData.AddedBy;
            modelData.Country = serviceData.Country;
            modelData.MerchantProfit = serviceData.MerchantProfit;
            modelData.DateAdded = serviceData.DateAdded;
            modelData.NumberOfOutlets = serviceData.NumberOfOutlets;

            return modelData;
        }
        
        [NonAction]
        public static MerchantService.MerchantModels GetServiceData(Models.MerchantModels modelData)
        {
            var serviceData = new MerchantService.MerchantModels();

            serviceData.MerchantName = modelData.MerchantName;
            serviceData.AddedBy = modelData.AddedBy;
            serviceData.Country = modelData.Country;
            serviceData.MerchantProfit = modelData.MerchantProfit;
            serviceData.DateAdded = modelData.DateAdded;
            serviceData.NumberOfOutlets = modelData.NumberOfOutlets;

            return serviceData;
        }
        
        [NonAction]
        public static List<Models.MerchantModels> GetListModelData(List<MerchantService.MerchantModels> serviceListData)
        {
            var modelListData = new List<Models.MerchantModels>();

            foreach (MerchantService.MerchantModels serviceData in serviceListData)
            {
                var modelData = new Models.MerchantModels();
                modelData.MerchantName = serviceData.MerchantName;
                modelData.AddedBy = serviceData.AddedBy;
                modelData.Country = serviceData.Country;
                modelData.MerchantProfit = serviceData.MerchantProfit;
                modelData.DateAdded = serviceData.DateAdded;
                modelData.NumberOfOutlets = serviceData.NumberOfOutlets;

                modelListData.Add(modelData);
            }

            return modelListData;
        }        
    }
}
